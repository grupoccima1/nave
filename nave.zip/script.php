<script src="https://code.jquery.com/jquery-3.3.1.js"></script>   
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>  
<script src="./public/bootstrap5/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/echarts/5.4.3/echarts.min.js"></script>
<script src="./public/js/app.js"></script>
<!-- <script src="js/main.js"></script> -->
<!-- <script src="js/operaciones.js"></script> -->
</body>
</html>